package com.example.cadastro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_Cadastrar=(Button)findViewById(R.id.btn_cadastrar);
        TextView txt_nome = (TextView) findViewById(R.id.txt_nome);
        TextView txt_sobrenome = (TextView) findViewById(R.id.txt_sobrenome);
        TextView txt_endereco = (TextView) findViewById(R.id.txt_endereco);
        TextView txt_telefone = (TextView) findViewById(R.id.txt_telefone);

        EditText txtP_Nome = (EditText) findViewById(R.id.txtP_Nome);
        EditText txtP_sobrenome = (EditText) findViewById(R.id.txtP_sobrenome);
        EditText txtP_endereco = (EditText) findViewById(R.id.txtP_endereco);
        EditText txtP_telefone = (EditText) findViewById(R.id.txtP_telefone);

        btn_Cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_nome .setText(txtP_Nome.getText());
                txt_sobrenome.setText(txtP_sobrenome.getText());
                txt_endereco.setText(txtP_endereco.getText());
                txt_telefone.setText(txtP_telefone.getText());
            }
        });



    }
}